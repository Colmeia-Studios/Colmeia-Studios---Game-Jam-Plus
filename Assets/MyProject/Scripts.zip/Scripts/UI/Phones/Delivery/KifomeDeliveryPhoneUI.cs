using System;
using System.Collections.Generic;
using TMPro;
using UnityEngine;
using UnityEngine.UI;

namespace ColmeiaStudios.SoMaisUmPedido
{
    public sealed class KifomeDeliveryPhoneUI : KifomePhoneUI
    {
        [Header("Delivery order list")] [SerializeField]
        private GameObject deliveryListView;

        [SerializeField] private Transform deliveryOrdersContent;
        [SerializeField] private KifomeOrderCardUI deliveryOrderCardPrefab;
        [SerializeField] private TMP_Text emptyOrdersText;

        [Header("Expanded order")] [SerializeField]
        private GameObject orderDetailsView;

        [SerializeField] private TMP_Text customerNameText;
        [SerializeField] private TMP_Text orderNumberText;
        [SerializeField] private TMP_Text mealNameText;
        [SerializeField] private TMP_Text remainingTimeText;
        [SerializeField] private TMP_Text addressText;
        [SerializeField] private TMP_Text houseDescriptionText;
        [SerializeField] private TMP_Text orderValueText;
        [SerializeField] private TMP_Text orderStatusText;
        [SerializeField] private Image housePhoto;
        [SerializeField] private Button backButton;
        [SerializeField] private Button deliveryActionButton;
        [SerializeField] private TMP_Text deliveryActionText;
        [SerializeField] private DeliveryUI backpackUI;
        [SerializeField] private List<UpgradeData> deliveryUpgrades = new List<UpgradeData>();

        private readonly List<KifomeOrderCardUI> orderCards = new List<KifomeOrderCardUI>();
        private readonly List<OrderRecord> visibleOrders = new List<OrderRecord>();
        private string detailsOrderId;

        protected override PlayerRole RequiredRole => PlayerRole.Delivery;
        protected override string PrimaryTabName => "Deliveries";

        protected override bool HasRequiredRoleReferences =>
            deliveryListView != null && deliveryOrdersContent != null &&
            deliveryOrderCardPrefab != null && orderDetailsView != null &&
            deliveryListView != orderDetailsView &&
            !IsSharedUpgradesView(deliveryListView) &&
            !IsSharedUpgradesView(orderDetailsView) &&
            !deliveryListView.transform.IsChildOf(orderDetailsView.transform) &&
            !orderDetailsView.transform.IsChildOf(deliveryListView.transform) &&
            customerNameText != null && orderNumberText != null && mealNameText != null &&
            remainingTimeText != null && addressText != null && houseDescriptionText != null &&
            orderValueText != null && orderStatusText != null &&
            backButton != null && deliveryActionButton != null && backpackUI != null;

        protected override IReadOnlyList<UpgradeData> UpgradeCatalog => deliveryUpgrades;

        protected override void ShowPrimaryViewContent()
        {
            detailsOrderId = null;
            ClearDetails();
            UpdateViewMode();
        }

        protected override void HidePrimaryViewContent()
        {
            detailsOrderId = null;
            ClearDetails();
            UpdateViewMode();
        }

        protected override void LogMissingRoleReferences()
        {
            if (deliveryListView == null)
            {
                Debug.LogError("KifomeDeliveryPhoneUI is missing its Deliveries view reference.", this);
            }

            if (deliveryOrdersContent == null)
            {
                Debug.LogError("KifomeDeliveryPhoneUI is missing its delivery card content reference.", this);
            }

            if (deliveryOrderCardPrefab == null)
            {
                Debug.LogError("KifomeDeliveryPhoneUI is missing its delivery order card prefab.", this);
            }

            if (orderDetailsView == null)
            {
                Debug.LogError("KifomeDeliveryPhoneUI is missing its Delivery Expand view reference.", this);
            }
            else if (deliveryListView == orderDetailsView ||
                     IsSharedUpgradesView(deliveryListView) ||
                     IsSharedUpgradesView(orderDetailsView) ||
                     deliveryListView != null &&
                     (deliveryListView.transform.IsChildOf(orderDetailsView.transform) ||
                      orderDetailsView.transform.IsChildOf(deliveryListView.transform)))
            {
                Debug.LogError(
                    "Deliveries, Delivery Expand, and Upgrades must be separate views; Deliveries and Delivery Expand cannot be parent/child of each other.",
                    this);
            }

            if (customerNameText == null) Debug.LogError("Delivery Expand is missing its customer name text.", this);
            if (orderNumberText == null) Debug.LogError("Delivery Expand is missing its order number text.", this);
            if (mealNameText == null) Debug.LogError("Delivery Expand is missing its meal name text.", this);
            if (remainingTimeText == null) Debug.LogError("Delivery Expand is missing its remaining time text.", this);
            if (addressText == null) Debug.LogError("Delivery Expand is missing its address text.", this);
            if (houseDescriptionText == null)
                Debug.LogError("Delivery Expand is missing its house description text.", this);
            if (orderValueText == null) Debug.LogError("Delivery Expand is missing its order value text.", this);
            if (orderStatusText == null) Debug.LogError("Delivery Expand is missing its order status text.", this);
            if (backButton == null) Debug.LogError("Delivery Expand is missing its return button.", this);
            if (deliveryActionButton == null)
                Debug.LogError("Delivery Expand is missing its delivery action button.", this);
            if (backpackUI == null) Debug.LogError("KifomeDeliveryPhoneUI is missing its external backpack UI.", this);
        }

        protected override void OnGameplayBound()
        {
            if (backpackUI != null && Owner != null && Match != null)
            {
                backpackUI.BindGameplay(Owner, Match);
            }
        }

        protected override void BindRoleListeners()
        {
            if (backButton != null)
            {
                backButton.onClick.RemoveListener(ShowDeliveryList);
                backButton.onClick.AddListener(ShowDeliveryList);
            }

            if (deliveryActionButton != null)
            {
                deliveryActionButton.onClick.RemoveListener(HandleOrderAction);
                deliveryActionButton.onClick.AddListener(HandleOrderAction);
            }
        }

        protected override void UnbindRoleListeners()
        {
            if (backButton != null) backButton.onClick.RemoveListener(ShowDeliveryList);
            if (deliveryActionButton != null) deliveryActionButton.onClick.RemoveListener(HandleOrderAction);
        }

        protected override void RefreshRoleOrders()
        {
            if (Owner == null || Orders == null ||
                deliveryOrdersContent == null || deliveryOrderCardPrefab == null)
            {
                return;
            }

            visibleOrders.Clear();
            IReadOnlyList<OrderRecord> activeOrders = Orders.ActiveOrders;
            for (int i = 0; i < activeOrders.Count; i++)
            {
                OrderRecord order = activeOrders[i];
                if (IsDisplayable(order))
                {
                    visibleOrders.Add(order);
                }
            }

            ResizeCards(visibleOrders.Count);
            if (emptyOrdersText != null)
            {
                emptyOrdersText.gameObject.SetActive(visibleOrders.Count == 0);
            }

            bool selectedOrderStillAvailable = false;
            for (int i = 0; i < visibleOrders.Count; i++)
            {
                OrderRecord order = visibleOrders[i];
                bool selected = string.Equals(
                    detailsOrderId,
                    order.OrderId,
                    StringComparison.OrdinalIgnoreCase);
                selectedOrderStillAvailable |= selected;
                orderCards[i].BindForDelivery(
                    order,
                    Orders,
                    Match,
                    true,
                    selected,
                    ShowOrderDetails);
            }

            if (!string.IsNullOrWhiteSpace(detailsOrderId) && !selectedOrderStillAvailable)
            {
                detailsOrderId = null;
            }

            UpdateViewMode();
            RefreshRoleDetails();
            RefreshNavigationIfOpen();
        }

        protected override void RefreshRoleDetails()
        {
            if (string.IsNullOrWhiteSpace(detailsOrderId) || Orders == null ||
                !Orders.TryGetOrder(detailsOrderId, out OrderRecord order) ||
                !IsDisplayable(order))
            {
                ClearDetails();
                return;
            }

            HouseData destination = order.Destination;
            customerNameText.text = destination != null ? destination.CustomerName : string.Empty;
            orderNumberText.text = $"PEDIDO #{order.OrderId}";
            mealNameText.text = order.DisplayName;
            remainingTimeText.text = $"{Orders.GetRemainingSeconds(order.OrderId):0}s";
            addressText.text = destination != null ? destination.Address : string.Empty;
            addressText.gameObject.SetActive(!string.IsNullOrWhiteSpace(addressText.text));
            houseDescriptionText.text = destination != null ? destination.Description : string.Empty;
            houseDescriptionText.gameObject.SetActive(!string.IsNullOrWhiteSpace(houseDescriptionText.text));
            orderValueText.text = $"Valor-base: R$ {order.BaseValue:0.00}";
            orderStatusText.text = order.State == OrderState.ReadyForPickup
                ? "Aguardando retirada no balcão"
                : "Na mochila";

            Sprite image = destination != null ? destination.HouseImage : null;
            if (housePhoto != null)
            {
                housePhoto.sprite = image;
                housePhoto.enabled = image != null;
                housePhoto.gameObject.SetActive(image != null);
            }

            bool readyForPickup = order.State == OrderState.ReadyForPickup;
            bool inInventory = order.State == OrderState.InDelivery &&
                               Owner != null && Owner.HasOrderInInventory(order.OrderId);
            bool hasPickupCapacity = Owner != null &&
                                     Owner.CarriedOrderIds.Count < Owner.InventoryCapacity;
            bool canChooseOrder = inInventory || readyForPickup && hasPickupCapacity;
            bool selectedForOrder = readyForPickup
                ? Owner != null && string.Equals(
                    Owner.SelectedPickupOrderId,
                    order.OrderId,
                    StringComparison.OrdinalIgnoreCase)
                : inInventory && string.Equals(
                    Owner.SelectedDeliveryOrderId,
                    order.OrderId,
                    StringComparison.OrdinalIgnoreCase);
            deliveryActionButton.interactable = canChooseOrder;
            if (deliveryActionText != null)
            {
                deliveryActionText.text = readyForPickup
                    ? !hasPickupCapacity
                        ? "Mochila cheia"
                        : selectedForOrder
                            ? "Desmarcar retirada"
                            : "Selecionar para retirada"
                    : selectedForOrder
                        ? "Desmarcar entrega"
                        : "Selecionar para entrega";
            }
        }

        protected override void AddRoleButtonsToNavigation()
        {
            if (IsPrimaryViewActive && orderDetailsView != null &&
                orderDetailsView.activeInHierarchy)
            {
                AddNavigableButton(backButton);
                AddNavigableButton(deliveryActionButton);
                return;
            }

            if (!IsPrimaryViewActive || deliveryListView == null ||
                !deliveryListView.activeInHierarchy)
            {
                return;
            }

            for (int i = 0; i < orderCards.Count; i++)
            {
                if (orderCards[i] != null)
                {
                    AddNavigableButton(orderCards[i].Button);
                }
            }
        }

        private void ShowOrderDetails(string orderId)
        {
            if (!IsPrimaryViewActive || Orders == null ||
                !Orders.TryGetOrder(orderId, out OrderRecord order) ||
                !IsDisplayable(order))
            {
                return;
            }

            detailsOrderId = order.OrderId;
            UpdateViewMode();
            RefreshRoleDetails();
            RefreshNavigationIfOpen();
        }

        private void ShowDeliveryList()
        {
            detailsOrderId = null;
            ClearDetails();
            UpdateViewMode();
            RefreshRoleOrders();
            RefreshNavigationIfOpen();
        }

        private void HandleOrderAction()
        {
            if (Owner == null || Orders == null ||
                string.IsNullOrWhiteSpace(detailsOrderId) ||
                !Orders.TryGetOrder(detailsOrderId, out OrderRecord order))
            {
                return;
            }

            bool selected = order.State == OrderState.ReadyForPickup
                ? Owner.SelectPickupOrder(order.OrderId)
                : order.State == OrderState.InDelivery &&
                  Owner.HasOrderInInventory(order.OrderId) &&
                  Owner.SelectDeliveryOrder(order.OrderId);
            if (!selected)
            {
                Owner.ShowGameplayMessage("O pedido não está disponível para esta ação.");
            }

            RefreshRoleDetails();
            RefreshRoleOrders();
        }

        private void UpdateViewMode()
        {
            bool showingDetails = IsPrimaryViewActive &&
                                  TryGetDetailsOrder(out _);
            deliveryListView.SetActive(IsPrimaryViewActive && !showingDetails);
            orderDetailsView.SetActive(showingDetails);

            if (!showingDetails)
            {
                detailsOrderId = null;
                ClearDetails();
            }
        }

        private bool TryGetDetailsOrder(out OrderRecord order)
        {
            order = null;
            return !string.IsNullOrWhiteSpace(detailsOrderId) &&
                   Orders != null &&
                   Orders.TryGetOrder(detailsOrderId, out order) &&
                   IsDisplayable(order);
        }

        private void ClearDetails()
        {
            if (customerNameText != null) customerNameText.text = string.Empty;
            if (orderNumberText != null) orderNumberText.text = string.Empty;
            if (mealNameText != null) mealNameText.text = string.Empty;
            if (remainingTimeText != null) remainingTimeText.text = string.Empty;
            if (addressText != null)
            {
                addressText.text = string.Empty;
                addressText.gameObject.SetActive(false);
            }

            if (houseDescriptionText != null)
            {
                houseDescriptionText.text = string.Empty;
                houseDescriptionText.gameObject.SetActive(false);
            }

            if (orderValueText != null) orderValueText.text = string.Empty;
            if (orderStatusText != null) orderStatusText.text = string.Empty;
            if (housePhoto != null)
            {
                housePhoto.sprite = null;
                housePhoto.enabled = false;
                housePhoto.gameObject.SetActive(false);
            }

            if (deliveryActionButton != null)
            {
                deliveryActionButton.interactable = false;
            }

            if (deliveryActionText != null)
            {
                deliveryActionText.text = string.Empty;
            }
        }

        private void ResizeCards(int count)
        {
            while (orderCards.Count > count)
            {
                int last = orderCards.Count - 1;
                if (orderCards[last] != null)
                {
                    Destroy(orderCards[last].gameObject);
                }

                orderCards.RemoveAt(last);
            }

            while (orderCards.Count < count)
            {
                orderCards.Add(Instantiate(deliveryOrderCardPrefab, deliveryOrdersContent));
            }
        }

        private static bool IsDisplayable(OrderRecord order)
        {
            return order != null &&
                   (order.State == OrderState.ReadyForPickup || order.State == OrderState.InDelivery);
        }
    }
}