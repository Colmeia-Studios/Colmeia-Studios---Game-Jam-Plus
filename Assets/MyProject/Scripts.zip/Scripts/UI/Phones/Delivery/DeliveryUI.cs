using System.Collections.Generic;
using TMPro;
using UnityEngine;

namespace ColmeiaStudios.SoMaisUmPedido
{
    public sealed class DeliveryUI : MonoBehaviour
    {
        [SerializeField] private PlayerController deliveryPlayer;
        [SerializeField] private Transform backpackContent;
        [SerializeField] private TMP_Text mealNamePrefab;
        [SerializeField] private TMP_Text backpackCountText;

        private readonly List<TMP_Text> mealNames = new List<TMP_Text>(3);
        private GameManager gameManager;
        private OrderManager orderManager;
        private bool initialized;

        private void OnEnable()
        {
            if (initialized)
            {
                Subscribe();
                Refresh();
            }
        }

        private void OnDisable()
        {
            Unsubscribe();
        }

        public void BindGameplay(PlayerController player, GameManager match)
        {
            Unsubscribe();
            deliveryPlayer = player;
            gameManager = match;
            orderManager = gameManager != null ? gameManager.Orders : null;

            if (deliveryPlayer == null || deliveryPlayer.AssignedRole != PlayerRole.Delivery ||
                gameManager == null || orderManager == null || backpackContent == null ||
                mealNamePrefab == null || backpackCountText == null)
            {
                Debug.LogError(
                    "DeliveryUI requires the delivery PlayerController, GameManager/OrderManager, backpack content, a meal-name text prefab, and a count text.",
                    this);
                initialized = false;
                return;
            }

            initialized = true;
            Subscribe();
            Refresh();
        }

        public void Refresh()
        {
            if (!initialized || deliveryPlayer == null || orderManager == null)
            {
                return;
            }

            IReadOnlyList<string> carriedIds = deliveryPlayer.CarriedOrderIds;
            int validCount = 0;
            for (int i = 0; i < carriedIds.Count; i++)
            {
                if (!orderManager.TryGetOrder(carriedIds[i], out OrderRecord order) ||
                    order.State != OrderState.InDelivery)
                {
                    continue;
                }

                validCount++;
                EnsureEntryCount(validCount);
                mealNames[validCount - 1].text = order.DisplayName;
            }

            EnsureEntryCount(validCount);
            backpackCountText.text = $"{validCount}/{deliveryPlayer.InventoryCapacity}";
        }

        private void EnsureEntryCount(int count)
        {
            while (mealNames.Count > count)
            {
                int last = mealNames.Count - 1;
                if (mealNames[last] != null)
                {
                    Destroy(mealNames[last].gameObject);
                }

                mealNames.RemoveAt(last);
            }

            while (mealNames.Count < count)
            {
                mealNames.Add(Instantiate(mealNamePrefab, backpackContent));
            }
        }

        private void Subscribe()
        {
            if (!initialized)
            {
                return;
            }

            if (deliveryPlayer != null)
            {
                deliveryPlayer.InventoryChanged -= Refresh;
                deliveryPlayer.InventoryChanged += Refresh;
            }

            if (orderManager != null)
            {
                orderManager.OrdersChanged -= Refresh;
                orderManager.OrdersChanged += Refresh;
            }
        }

        private void Unsubscribe()
        {
            if (deliveryPlayer != null)
            {
                deliveryPlayer.InventoryChanged -= Refresh;
            }

            if (orderManager != null)
            {
                orderManager.OrdersChanged -= Refresh;
            }
        }

        private void OnDestroy()
        {
            Unsubscribe();
        }
    }
}
