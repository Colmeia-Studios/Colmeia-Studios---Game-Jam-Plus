using System;
using System.Text;
using TMPro;
using UnityEngine;
using UnityEngine.UI;

namespace ColmeiaStudios.SoMaisUmPedido
{
    public sealed class KifomeDeliveryCardUI : MonoBehaviour
    {
        
    }
}