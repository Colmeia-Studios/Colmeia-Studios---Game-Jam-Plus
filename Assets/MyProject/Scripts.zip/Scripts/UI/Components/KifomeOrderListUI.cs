using TMPro;
using UnityEngine;
using UnityEngine.UI;

namespace ColmeiaStudios.SoMaisUmPedido
{
    public sealed class KifomeOrderListUI : MonoBehaviour
    {
        [SerializeField] private TMP_Text ingredientText;
        [SerializeField] private Image stateIcon;
        [SerializeField] private Color pendingColor = new Color(0.72f, 0.62f, 0.48f);
        [SerializeField] private Color completedColor = new Color(0.22f, 0.62f, 0.3f);

        public void Configure(TMP_Text ingredientName, Image stateImage)
        {
            ingredientText = ingredientName;
            stateIcon = stateImage;
        }

        public void SetState(IngredientData ingredient, string fallbackName, bool placed)
        {
            if (ingredientText != null)
            {
                ingredientText.text = ingredient != null && !string.IsNullOrWhiteSpace(ingredient.DisplayName)
                    ? ingredient.DisplayName
                    : fallbackName;
            }

            if (stateIcon != null)
            {
                stateIcon.color = placed ? completedColor : pendingColor;
            }
        }
    }
}