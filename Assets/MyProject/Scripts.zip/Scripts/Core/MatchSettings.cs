using UnityEngine;
using UnityEngine.InputSystem;

namespace ColmeiaStudios.SoMaisUmPedido
{
    public enum PlayerRole
    {
        Cook,
        Delivery
    }

    public static class MatchSettings
    {
        public static readonly string CharacterOne = "Cozinheiro";
        public static readonly string CharacterTwo = "Entregador";
        public static PlayerRole PlayerOneRole { get; private set; } = PlayerRole.Cook;
        public static PlayerRole PlayerTwoRole { get; private set; } = PlayerRole.Delivery;
        public static InputDevice PlayerOneDevice { get; private set; }
        public static InputDevice PlayerTwoDevice { get; private set; }
        public static Mouse PlayerOneMouse { get; private set; }
        public static Keyboard PlayerOneKeyboard { get; private set; }
        public static Mouse PlayerTwoMouse { get; private set; }
        public static string PlayerOneScheme { get; private set; }
        public static string PlayerTwoScheme { get; private set; }

        public static void SetRoles(PlayerRole playerOneRole, PlayerRole playerTwoRole)
        {
            PlayerOneRole = playerOneRole;
            PlayerTwoRole = playerTwoRole;
        }

        public static void ResetToDefault()
        {
            SetRoles(PlayerRole.Cook, PlayerRole.Delivery);
            PlayerOneDevice = null;
            PlayerTwoDevice = null;
            PlayerOneMouse = null;
            PlayerOneKeyboard = null;
            PlayerTwoMouse = null;
            PlayerOneScheme = null;
            PlayerTwoScheme = null;
        }

        public static bool SetMatch(PlayerRole playerOneRole, PlayerRole playerTwoRole,
            InputDevice playerOneDevice, string playerOneScheme, Mouse playerOneMouse,
            InputDevice playerTwoDevice, string playerTwoScheme, Mouse playerTwoMouse)
        {
            Keyboard keyboard = playerOneDevice as Keyboard;
            return SetMatch(playerOneRole, playerTwoRole, playerOneDevice, playerOneScheme,
                playerOneMouse, keyboard, playerTwoDevice, playerTwoScheme, playerTwoMouse);
        }

        public static bool SetMatch(PlayerRole playerOneRole, PlayerRole playerTwoRole,
            InputDevice playerOneDevice, string playerOneScheme, Mouse playerOneMouse, Keyboard playerOneKeyboard,
            InputDevice playerTwoDevice, string playerTwoScheme, Mouse playerTwoMouse)
        {
            return TrySetMatch(playerOneRole, playerTwoRole, playerOneDevice, playerOneScheme,
                playerOneMouse, playerOneKeyboard, playerTwoDevice, playerTwoScheme, playerTwoMouse, out _);
        }

        public static bool TrySetMatch(PlayerRole playerOneRole, PlayerRole playerTwoRole,
            InputDevice playerOneDevice, string playerOneScheme, Mouse playerOneMouse, Keyboard playerOneKeyboard,
            InputDevice playerTwoDevice, string playerTwoScheme, Mouse playerTwoMouse, out string reason)
        {
            if (!IsValidRole(playerOneRole) || !IsValidRole(playerTwoRole) || playerOneRole == playerTwoRole)
            { reason = "Os dois jogadores precisam ter funções válidas e diferentes."; return false; }
            if (!IsValidAssignment(playerOneDevice, playerOneScheme, playerOneMouse, playerOneKeyboard, out reason))
            { reason = $"Player 1: {reason}"; return false; }
            if (!IsValidAssignment(playerTwoDevice, playerTwoScheme, playerTwoMouse, null, out reason))
            { reason = $"Player 2: {reason}"; return false; }

            var firstDevices = new System.Collections.Generic.HashSet<InputDevice>();
            AddIfPresent(firstDevices, playerOneDevice); AddIfPresent(firstDevices, playerOneKeyboard); AddIfPresent(firstDevices, playerOneMouse);
            var secondDevices = new System.Collections.Generic.HashSet<InputDevice>();
            AddIfPresent(secondDevices, playerTwoDevice); AddIfPresent(secondDevices, playerTwoMouse);
            if (firstDevices.Count != CountDevices(playerOneDevice, playerOneKeyboard, playerOneMouse) ||
                secondDevices.Count != CountDevices(playerTwoDevice, null, playerTwoMouse))
            { reason = "Um jogador tem o mesmo dispositivo listado mais de uma vez."; return false; }
            foreach (InputDevice device in firstDevices)
                if (secondDevices.Contains(device))
                { reason = $"O dispositivo '{device.displayName}' seria compartilhado entre os jogadores."; return false; }

            SetRoles(playerOneRole, playerTwoRole);
            PlayerOneDevice = playerOneDevice;
            PlayerTwoDevice = playerTwoDevice;
            PlayerOneMouse = playerOneMouse;
            PlayerOneKeyboard = playerOneKeyboard;
            PlayerTwoMouse = playerTwoMouse;
            PlayerOneScheme = playerOneScheme;
            PlayerTwoScheme = playerTwoScheme;
            reason = "Pareamento válido.";
            return true;
        }

        private static bool IsValidAssignment(InputDevice device, string scheme, Mouse mouse, Keyboard keyboard, out string reason)
        {
            if (device == null || !device.added)
            { reason = "dispositivo principal ausente ou desconectado."; return false; }

            if (scheme == "KeyboardMouse")
            {
                bool valid = device is Keyboard && mouse != null && mouse.added && (keyboard == null || keyboard == device);
                reason = valid ? "" : "KeyboardMouse exige um teclado e um mouse conectados.";
                return valid;
            }

            if (scheme == "Gamepad")
            {
                bool valid = device is Gamepad && mouse == null && keyboard == null;
                reason = valid ? "" : "Gamepad exige um gamepad sem periféricos compartilhados.";
                return valid;
            }

            if (scheme == "GamepadKeyboardMouse")
            {
                bool valid = device is Gamepad && mouse != null && mouse.added && keyboard != null && keyboard.added;
                reason = valid ? "" : "O esquema híbrido exige gamepad, teclado e mouse conectados.";
                return valid;
            }

            reason = $"esquema '{scheme}' não reconhecido.";
            return false;
        }

        private static void AddIfPresent(System.Collections.Generic.HashSet<InputDevice> set, InputDevice device)
        { if (device != null) set.Add(device); }
        private static int CountDevices(InputDevice first, InputDevice second, InputDevice third)
        { return (first != null ? 1 : 0) + (second != null ? 1 : 0) + (third != null ? 1 : 0); }

        private static bool IsValidRole(PlayerRole role)
        {
            return role == PlayerRole.Cook || role == PlayerRole.Delivery;
        }
    }
}
